
export const siteConfig = {
  name: 'Redwan Kabir',
  title: 'Geographic Information System Specialist',
  subtitle: 'Spatial Analytics • Web GIS • Remote Sensing • Python',
  email: 'smredwan.kabir@wmich.edu',
  photo: '/assets/profile.jpg',
  cv: 'assets/RedwanKabir_CV.pdf',
  social: {
    linkedin: 'https://www.linkedin.com/in/redwankabir95/',
    github: 'https://github.com/redwan95',
    researchgate: 'https://www.researchgate.net/profile/S-M-Redwan-Kabir'
  },
  about: `GIS Analyst and Urban Planner with expertise in geospatial analytics, remote sensing, and machine learning. Experienced in leveraging spatial data science to advance infrastructure resilience and sustainable urban planning.`,
  objective: `To leverage geospatial analytics, predictive modeling, and AI to advance infrastructure resilience and sustainable energy transitions. My focus is on modeling risks from extreme weather, analyzing equitable adoption of autonomous and electric vehicles, and developing data-driven tools that support adaptive planning and decision-making for sustainable urban and rural systems.`,
  education: [
    { degree: 'M.S. in Geography (Geospatial Applications)', cgpa: '3.94 / 4.00', school: 'Western Michigan University', period: '2022 — 2024' },
    { degree: 'B.Sc. in Urban & Regional Planning', cgpa: '3.62 / 4.00', school: 'Khulna University of Engineering & Technology', period: '2013 — 2017' }
  ],
  skills: {
    geospatial: ['ArcGIS Pro','ArcGIS Online','QGIS','ArcGIS Dashboards'],
    remote: ['ENVI','Google Earth Engine','Landsat/Sentinel','MODIS','Pix4D'],
    programming: ['Python','R','SQL','ArcPy','Pandas/GeoPandas','Random Forest','XGBoost','Artificial Neural Networks','Linear Regression'],
    arcgisTools: ['Model Builder','Spatial Analyst','Network Analyst','3D Analyst'],
    survey: ['Survey123','ArcGIS Field Maps','Trimble R2 GNSS','GPS Data Collection']
  },
  projectCategories: ['All','Interactive Web Maps & Dashboards','Data Mining & Environmental Modelling','Spatial Analysis','UAS'],
  projects: [
    // Dashboards & StoryMaps
    { id:'p1', cat:'Interactive Web Maps & Dashboards', title:'Real-time 911 Public Safety Dashboard (Redland County, CA)', description:'ArcGIS Dashboard showing live incident KPIs.', viewUrl:'https://www.arcgis.com/apps/dashboards/9fcff794eb2f4ccba5b96f02944aeb19', embedUrl:'https://www.arcgis.com/apps/dashboards/9fcff794eb2f4ccba5b96f02944aeb19' },
    { id:'p2', cat:'Interactive Web Maps & Dashboards', title:'Flood Monitoring Dashboard — Missouri Dept. of Conservation', description:'Real-time flood indicators & layers.', viewUrl:'https://www.arcgis.com/apps/dashboards/f26e06c18ff24a1bab746fd4e24e8a9e', embedUrl:'https://www.arcgis.com/apps/dashboards/f26e06c18ff24a1bab746fd4e24e8a9e' },

    // Data Mining & Environmental Modelling
    { id:'m1', cat:'Data Mining & Environmental Modelling', title:'Weather Trends Analysis with Python', description:'EDA & trend detection for climate/weather data.', viewUrl:'https://github.com/redwan95/weather-trends-python' },
    { id:'m2', cat:'Data Mining & Environmental Modelling', title:'Machine Learning Model for LST Data', description:'LST modeling & validation with RF/XGBoost.', viewUrl:'https://github.com/redwan95/lst-ml-model' },
    { id:'m3', cat:'Data Mining & Environmental Modelling', title:'Landsat Image Automation with Google Earth Engine', description:'Automated imagery pipelines (masking, export).', viewUrl:'https://github.com/redwan95/landsat-gee-automation' },
    { id:'m4', cat:'Data Mining & Environmental Modelling', title:'Quantile Mapping for Landsat LST', description:'Bias-correction aligning Landsat LST with MODIS.', viewUrl:'https://github.com/redwan95/lst-quantile-mapping' },

    // Spatial Analysis
    { id:'s1', cat:'Spatial Analysis', title:'Quantile Mapping for Landsat LST', description:'Spatiotemporal bias correction & analysis for urban LST.', viewUrl:'https://github.com/redwan95/lst-quantile-mapping' },
    { id:'s2', cat:'Spatial Analysis', title:'Michigan Clinic Drive Time Analysis', description:'Network accessibility metrics & visualization.', viewUrl:'https://wmugeography.maps.arcgis.com/home/webmap/viewer.html?layers=091407613c414685a983f33d894bf194&useExisting=1', embedUrl:'https://wmugeography.maps.arcgis.com/home/webmap/viewer.html?layers=091407613c414685a983f33d894bf194&useExisting=1' },
    { id:'s3', cat:'Spatial Analysis', title:'Detroit Medical Underserved Areas', description:'Census-based assessment & spatial equity mapping.', viewUrl:'https://github.com/redwan95/detroit-medical-underserved-areas' },

    // UAS
    { id:'u1', cat:'UAS', title:'Streamlit: OSM Mapping Dashboard', description:'Interactive analytics & tiles.', viewUrl:'https://osmmapping-mwzkbj8sxmhgbusvmymrdt.streamlit.app/', embedUrl:'https://osmmapping-mwzkbj8sxmhgbusvmymrdt.streamlit.app/' }
  ],
  publications: [
    { title:'Spatiotemporal Variability of Land Surface Temperature in Chicago, Illinois', venue:'Master’s Thesis, WMU (2024)', link:'https://scholarworks.wmich.edu/masters_theses/5402/' },
    { title:'Enhancing Urban Thermal Mapping via Quantile Correction of Landsat LST with MODIS (Manuscript in progress)', venue:'2025' },
    { title:'Assessing the Performance of Highway based on Speed Study Analysis: Khulna-Jessore Highway', venue:'ICPACe 2017', link:'https://www.researchgate.net/publication/377781190_Assessing_the_Performance_of_Highway_based_on_Speed_Study_Analysis_A_Case_Study_of_Khulna-Jessore_Highway' },
    { title:'Traffic Congestion at Road Intersection: Fulbarigate, Khulna', venue:'ICCESD-2016', link:'https://www.researchgate.net/publication/377781185_Traffic_Congestion_at_Road_Intersection_due_to_Absence_of_Efficient_Traffic_Management_and_Planning_A_Case_Study_on_Fulbarigate_Khulna' },
    { title:'Evaluation of Inland Waterway Freight Transport System in Khulna City', venue:'Civil Engineering Summit (2017)', link:'https://www.researchgate.net/publication/325321677_Evaluation_of_Inland_Water_Freight_Transport_System_in_Khulna_City_A_Case_Study_on_Dakbanglow_to_Rupsha_Ferry_Ghat' }
  ],
  awards: [
    { title:'Student Travel Grant — Graduate College, Western Michigan University (Nov 2023)', link:'https://wmich.edu/grad/awards' },
    { title:'Student Research Grant — Graduate College, Western Michigan University (Apr 2023)', link:'https://wmich.edu/grad/awards' },
    { title:'Champion Award, Case Study Analysis Competition — Islamic University of Technology (2015)', link:'https://drive.google.com/file/d/1pXkWUPmrnanayZjg0onk7qC70PG_dWCW/view?usp=sharing' },
    { title:'L. Harrison Graduate Tuition Scholarship (Full Waiver) — Western Michigan University (Aug 2022 – Apr 2024)' },
    { title:'Undergraduate Technical Scholarship — Khulna University of Engineering & Technology (KUET)' }
  ]
}
