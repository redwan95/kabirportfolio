
import React, { useState, useEffect } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Education from './components/Education'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Publications from './components/Publications'
import Honors from './components/Honors'
import Contact from './components/Contact'
import Loader from './components/Loader'

export default function App(){
  const [dark, setDark] = useState(true)
  const [loading, setLoading] = useState(true)

  useEffect(()=>{
    document.documentElement.classList.toggle('dark', dark)
  },[dark])

  useEffect(()=>{
    const t = setTimeout(()=> setLoading(false), 1500)
    return ()=> clearTimeout(t)
  },[])

  return (
    <div className="min-h-screen flex flex-col">
      {loading && <Loader />}
      <Navbar dark={dark} setDark={setDark} />
      <main className="flex-grow">
        <Hero />
        <About />
        <section className="section"><div className="container card"><h2 className="h2">Research Objective</h2><p className="mt-3 text-slate-700 dark:text-slate-200 whitespace-pre-line">To leverage geospatial analytics, predictive modeling, and AI to advance infrastructure resilience and sustainable energy transitions. My focus is on modeling risks from extreme weather, analyzing equitable adoption of autonomous and electric vehicles, and developing data-driven tools that support adaptive planning and decision-making for sustainable urban and rural systems.</p></div></section>
        <Education />
        <Skills />
        <Projects />
        <Publications />
        <Honors />
        <Contact />
      </main>
    </div>
  )
}
