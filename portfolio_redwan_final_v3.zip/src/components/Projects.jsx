
import React, { useState, useMemo } from 'react'
import { siteConfig } from '../siteConfig'

export default function Projects(){
  const [tab, setTab] = useState('All')
  const tabs = siteConfig.projectCategories
  const items = useMemo(()=> tab==='All' ? siteConfig.projects : siteConfig.projects.filter(p=>p.cat===tab), [tab])

  return (
    <section id="projects" className="section">
      <div className="container">
        <h2 className="h2">Projects & Applications</h2>

        <div className="mt-5 flex flex-wrap gap-2">
          {tabs.map(t => (
            <button key={t} onClick={()=>setTab(t)} className={`tab ${tab===t? 'tab-active' : ''}`}>{t}</button>
          ))}
        </div>

        <div className="mt-6 grid md:grid-cols-2 gap-6">
          {items.map(p => (
            <details key={p.id} className="card hover:shadow-xl transition">
              <summary className="cursor-pointer select-none">
                <div className="font-semibold">{p.title}</div>
                <p className="text-sm text-slate-600 dark:text-slate-300">{p.description}</p>
              </summary>
              <div className="mt-4 space-x-3">
                {p.viewUrl && <a className="btn btn-primary" href={p.viewUrl} target="_blank" rel="noreferrer">View Project</a>}
              </div>
              {p.embedUrl && (
                <div className="embed-box mt-4">
                  <iframe src={p.embedUrl} loading="lazy" allowFullScreen title={p.title}></iframe>
                </div>
              )}
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
