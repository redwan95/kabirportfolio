
import React from 'react'
import { siteConfig } from '../siteConfig'

export default function Publications(){
  return (
    <section id="publications" className="section">
      <div className="container">
        <h2 className="h2">Publications</h2>
        <ul className="mt-6 space-y-3">
          {siteConfig.publications.map((p, i) => (
            <li key={i} className="card flex items-center justify-between gap-4 hover:shadow-xl transition">
              <div>
                <div className="font-medium">{p.title}</div>
                {p.venue && <div className="text-sm text-slate-500 dark:text-slate-300">{p.venue}</div>}
              </div>
              {p.link && <a className="btn btn-primary" href={p.link} target="_blank" rel="noreferrer">View</a>}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
