
import React from 'react'
import { siteConfig } from '../siteConfig'

export default function Education(){
  return (
    <section id="education" className="section">
      <div className="container">
        <h2 className="h2">Education</h2>
        <div className="mt-6 grid md:grid-cols-2 gap-6">
          {siteConfig.education.map((e, i) => (
            <div key={i} className="card hover:shadow-xl transition">
              <div className="font-semibold">{e.degree}</div>
              <div className="text-sm text-slate-500 dark:text-slate-300">{e.school} • {e.period}</div>
              {e.cgpa && <div className="mt-2 text-sm"><span className="font-medium">CGPA:</span> {e.cgpa}</div>}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
