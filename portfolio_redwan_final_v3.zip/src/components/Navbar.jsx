
import React from 'react'
import { siteConfig } from '../siteConfig'
const base = import.meta.env.BASE_URL || '/'

export default function Navbar({dark, setDark}){
  const Item = ({href, label}) => (<a href={href} className="hover:underline">{label}</a>)
  return (
    <nav className="bg-white/80 dark:bg-slate-900/80 backdrop-blur border-b border-slate-200 dark:border-slate-800 sticky top-0 z-50">
      <div className="container flex items-center justify-between py-3">
        <div className="flex items-center gap-3 font-semibold">
          <div className="nav-logo">RK</div>
          <span className="hidden sm:inline">Portfolio</span>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <Item href="#about" label="About" />
          <Item href="#education" label="Education" />
          <Item href="#skills" label="Skills" />
          <Item href="#projects" label="Projects" />
          <Item href="#publications" label="Publications" />
          <Item href="#honors" label="Honors" />
          <Item href="#contact" label="Contact" />
          <a href={`${base}${siteConfig.cv}`} target="_blank" rel="noreferrer" className="btn btn-primary">Download CV</a>
          <button onClick={()=>setDark(!dark)} className="btn">{dark? 'Light' : 'Dark'}</button>
        </div>
      </div>
    </nav>
  )
}
