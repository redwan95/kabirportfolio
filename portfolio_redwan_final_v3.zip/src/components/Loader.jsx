
import React from 'react'

export default function Loader(){
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-white/75 dark:bg-slate-900/75">
      <div className="relative">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-teal-500 via-cyan-500 to-blue-600 grid place-items-center text-white text-lg font-bold animate-pulse shadow-lg">RK</div>
        <div className="w-20 h-20 rounded-full border-4 border-teal-400/30 border-t-teal-500 animate-spin absolute -inset-2"></div>
      </div>
    </div>
  )
}
