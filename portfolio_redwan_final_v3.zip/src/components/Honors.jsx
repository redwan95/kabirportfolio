
import React from 'react'
import { siteConfig } from '../siteConfig'

export default function Honors(){
  return (
    <section id="honors" className="section">
      <div className="container">
        <h2 className="h2">Awards • Certifications</h2>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <div className="card hover:shadow-xl transition">
            <h3 className="h3 mb-3">Awards</h3>
            <ul className="space-y-2">
              {siteConfig.awards.map((a,i)=>(
                <li key={i} className="flex items-center justify-between gap-4">
                  <span>{a.title}</span>
                  {a.link && <a className="btn btn-primary" href={a.link} target="_blank" rel="noreferrer">View</a>}
                </li>
              ))}
            </ul>
          </div>

          <div className="card hover:shadow-xl transition">
            <h3 className="h3 mb-3">Certifications</h3>
            <ul className="space-y-2">
              <li className="flex items-center justify-between">
                <span>Professional Certificate (Doc 1)</span>
                <a className="btn btn-primary" href="https://drive.google.com/file/d/11AHooF0JG3Cut8Lwt_CvNcgu6ycjKiv8/view" target="_blank" rel="noreferrer">View</a>
              </li>
              <li className="flex items-center justify-between">
                <span>Professional Certificate (Doc 2)</span>
                <a className="btn btn-primary" href="https://drive.google.com/file/d/1qccaJZrQyZZi5EVStCtklkxIYn-dWP5b/view?usp=sharing" target="_blank" rel="noreferrer">View</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
