
import React from 'react'
import { siteConfig } from '../siteConfig'

export default function Contact(){
  const { email, social } = siteConfig
  return (
    <section id="contact" className="section">
      <div className="container card hover:shadow-xl transition">
        <h2 className="h2">Contact</h2>
        <p className="mt-2">Email: <a className="link" href={`mailto:${email}`}>{email}</a></p>
        <div className="mt-3 flex flex-wrap gap-3 text-sm">
          {social.linkedin && <a className="link" href={social.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>}
          {social.github && <a className="link" href={social.github} target="_blank" rel="noreferrer">GitHub</a>}
          {social.researchgate && <a className="link" href={social.researchgate} target="_blank" rel="noreferrer">ResearchGate</a>}
        </div>
      </div>
    </section>
  )
}
