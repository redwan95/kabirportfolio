
import React from 'react'
import { siteConfig } from '../siteConfig'

const Row = ({title, items}) => (
  <div className="card hover:shadow-xl transition">
    <h3 className="h3 mb-3">{title}</h3>
    <div className="flex flex-wrap gap-2">
      {items.map((it,idx)=>(<span key={idx} className="chip">{it}</span>))}
    </div>
  </div>
)

export default function Skills(){
  const s = siteConfig.skills
  return (
    <section id="skills" className="section">
      <div className="container">
        <h2 className="h2">Technical Skills</h2>
        <div className="mt-6 grid gap-6">
          <Row title="Geospatial Products" items={s.geospatial} />
          <Row title="Remote Sensing" items={s.remote} />
          <Row title="Programming & Statistics" items={s.programming} />
          <Row title="ArcGIS Tools" items={s.arcgisTools} />
          <Row title="Survey & Field Data" items={s.survey} />
        </div>
      </div>
    </section>
  )
}
