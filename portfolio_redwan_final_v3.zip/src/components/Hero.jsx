
import React from 'react'
import { siteConfig } from '../siteConfig'

export default function Hero(){
  const { name, title, subtitle, social } = siteConfig
  return (
    <header className="section">
      <div className="container">
        <h1 className="h1 bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-500 text-transparent bg-clip-text">{name}</h1>
        <p className="mt-3 text-2xl font-semibold">{title}</p>
        <p className="text-slate-500 dark:text-slate-300">{subtitle}</p>
        <div className="mt-4 flex flex-wrap items-center gap-4 text-base">
          <a className="link" href={`mailto:${siteConfig.email}`}>Email</a>
          {social.linkedin && <a className="link" href={social.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>}
          {social.github && <a className="link" href={social.github} target="_blank" rel="noreferrer">GitHub</a>}
          {social.researchgate && <a className="link" href={social.researchgate} target="_blank" rel="noreferrer">ResearchGate</a>}
        </div>
      </div>
    </header>
  )
}
