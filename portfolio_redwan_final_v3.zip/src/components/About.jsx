
import React, { useRef, useState } from 'react'
import { siteConfig } from '../siteConfig'

export default function About(){
  const fileRef = useRef(null)
  const [preview, setPreview] = useState(siteConfig.photo)
  const onChangePhoto = (e) => { const f=e.target.files?.[0]; if(!f) return; const r=new FileReader(); r.onload=()=>setPreview(r.result); r.readAsDataURL(f) }

  return (
    <section id="about" className="section">
      <div className="container grid md:grid-cols-3 gap-8 items-start">
        <div className="card">
          <img src={preview} alt="Profile" className="w-44 h-44 object-cover rounded-full border border-slate-200 dark:border-slate-700 shadow" />
          <button className="btn mt-3" onClick={()=>fileRef.current?.click()}>Upload / Change Photo</button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onChangePhoto} />
          <p className="text-xs text-slate-500 mt-2">Replace <code>public/assets/profile.jpg</code> and redeploy to persist.</p>
        </div>
        <div className="md:col-span-2">
          <h2 className="h2">About</h2>
          <p className="mt-4 text-slate-700 dark:text-slate-200 whitespace-pre-line">{siteConfig.about}</p>
        </div>
      </div>
    </section>
  )
}
