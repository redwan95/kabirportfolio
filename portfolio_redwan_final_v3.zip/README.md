
# Redwan Kabir — Portfolio (Final v3)

- Professional Modern: strong fonts, dark/light, smooth transitions
- Text-only skills (no icons), clean chips
- Publications with links
- Projects with GitHub links for Python works
- Awards with provided URLs
- Loader hides after 1.5s

## Run
npm install
npm run dev

## Deploy
npm run deploy  # GitHub Pages (repo redwan/portfolio, branch gh-pages)

## Edit
Change everything in `src/siteConfig.js`.
